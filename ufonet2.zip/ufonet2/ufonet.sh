#!/data/data/com.termux/files/usr/bin/bash
clear
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
date = 'date'
clear
echo $yellow"""                                   ++++                 
                              +hmNmhhhhmNmh+       <!VERSION V2.0>        
                           +hNd+ +      +  hNd     <!10-10-19>      
                         yMh    mmmmmmmm    yMh    <!Down System Family>   
                         mN   odNMMMMMMMdo    Nm             
                       +hM  +oNMMMMMMMMMMMMMy   Nm               
                       +Mh +hMMMMMMMMMMMMMMMMm  sM+              
                       oM+ sMMMMMMMMNNNMMMMMMMh  My                 
                      oMo+mMMMMN   mm   omMMMMN My +++         
                 ++   +Md+mMMNo   mmmm   MMMmhMNMMMMMMN        
                mMMm+  sMsyMMMd    mm    MMMhoMMMMhMmmm         
                 +NMMo +yMhmMMMMNyooo+yNMMMMmyMdMMM             
                  yMMh    mNNMMMMMMMMMMMMMMNNN++hMMh+             
                  dMM+    ++dMMMMMMMMMMMMMMmo+  -NMM+              
                  MMMb         dMMMMMMMMh+       yMMd+            
                  NMMNhyhhhyomoNMMMMMMMMm       +hMMd+          
                   yNMMMMMMMMMMMNNMMMMMMMNyo++oymMMM/  dMhm      
                ++osysmmmhh+oommNMMMMMydMMMMMMMMmym  mNMM+        
                dMMMMMMNdyssssyymMMhhMMNs+shdmmdhomm+hNMMdh        
                oso: sdNMMMMMMMMMmssoNMMMMMMMMMMMMMMMMdhhh"""
echo
echo $white"───────────────────────────────────────────────────────────────────────────"
echo
echo $red"       Ufonet" $yellow"- Is a toolkit designet to launch $red"Dos" $yellow"And" $red"DDoS Attack
echo $yellow"          REMEMBER -> This code is NOT for educational purpose!!"
echo
echo $white"───────────────────────────────────────────────────────────────────────────"



echo $red"""             ┌─────────────────────────────────────────────┐
--start      │                                             │ 
--help       │               STARTMOTHERSHIP               │
--exit       │                                             │
--install    └─────────────────────────────────────────────┘ 
 
"""

echo " 🔻╭─[~Termux/Ufonet.sh]" 
read -p "   ╰────>" in;


if [ $in = --start ] || [ $in = --start ]
then
cd core #Membuka directory
sh main.sh #menjalankan file main
fi

if [ $in = --help ] || [ $in = --help ]
then
echo
echo $white"COMMAND 
--help 
--start
--exit "
echo
fi

if [ $in = --exit ] || [ $in = --exit ]
then
exit
fi


if [ $in = --install ] || [ $in = --install ]
then
pkg install toilet
pkg lnstall ruby
gem install lolcat
pkg install pip2
pkg install nano
pkg install curl
pkg install clang
pkg install python
pkg install perl
pkg install python2
pkg install php
sleep 1
echo $blue"SELESAI"
sleep 1
sh ufonet.sh
fi